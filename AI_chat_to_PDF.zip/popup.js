document.getElementById('generatePdf').addEventListener('click', () => {
    const status = document.getElementById('status');
    status.textContent = 'Generating PDF...';
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: generatePDF
        }, () => {
            status.textContent = 'PDF generation complete!';
            setTimeout(() => { status.textContent = ''; }, 3000);
        });
    });
});

function generatePDF() {
    let elements = [], csp = false;
    switch (location.hostname) {
        case 'claude.ai':
            elements.push(document.querySelector('div[data-test-render-count]').parentElement);
            elements.push(document.querySelector('div.ease-out.w-full[class*="overflow-"]'));
            break;
        case 'chatgpt.com':
            elements.push(document.querySelector('article').parentElement);
            elements.push(document.querySelector('section.popover>main'));
            csp = true;
            break;
        case 'grok.com':
            elements.push(document.querySelector('div.\\@container\\/main>div:first-child>div'));
            elements.push(document.querySelector('aside'));
            break;
        case 'gemini.google.com':
            elements.push(document.querySelector('#chat-history'));
            elements.push(document.querySelector('extended-response-panel response-container'));
            csp = true;
            break;
        default:
            alert(location.hostname + ' is not supported');
            return;
    }
    console.debug(`Found elements at ${location.hostname}:`, elements);
    elements = elements.filter(n => n);
    if (csp || confirm('Confirm if a PDF should be searchable')) {
        let temp = document.createElement('div');
        temp.id = 'id-' + Math.random().toString(36).slice(2, 9);
        elements.forEach(el => el && temp.appendChild(el.cloneNode(true)));
        let style = document.createElement('style');
        style.textContent = `@media print{body>*{display:none!important}#${temp.id}{display:flex!important;flex-direction:column}}`;
        document.head.appendChild(style);
        document.body.appendChild(temp);
        window.print();
        setTimeout(() => {
            document.head.removeChild(style);
            document.body.removeChild(temp);
        }, 1000);
    } else {
        let script = document.createElement('script');
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.3/html2pdf.bundle.min.js';
        script.onload = function () {
            let ts = new Date().toISOString().replace(/[-:T.]/g, '').slice(0, 14);
            let pdf = html2pdf().set({ margin: 5, filename: `${ts}.pdf`, html2canvas: {scale: 2, logging: false} }).from(elements.shift());
            elements.forEach(el => pdf = pdf.toPdf().get('pdf').then(pdfObj => pdfObj.addPage()).from(el).toContainer().toCanvas().toPdf());
            pdf.save();
        };
        document.body.appendChild(script);
    }
}