// Content script to communicate with popup and execute PDF generation
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'generatePDF') {
        generatePDF();
        sendResponse({ status: 'success' });
    }
});